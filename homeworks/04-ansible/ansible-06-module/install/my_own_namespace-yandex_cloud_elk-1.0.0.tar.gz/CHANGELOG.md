# Changelog

## 1.0.0

- Первый релиз: модуль `my_own_module`, роль `my_own_role`, playbook `playbooks/site.yml`.
