# Ansible Collection `my_own_namespace.yandex_cloud_elk`

Учебная коллекция к домашнему заданию Netology «Создание собственных модулей».
Содержит собственный модуль, создающий текстовый файл, и роль, которая его использует.

## Состав

| Тип | Имя | Назначение |
|---|---|---|
| Модуль | `my_own_namespace.yandex_cloud_elk.my_own_module` | Создаёт текстовый файл по пути `path` с содержимым `content` |
| Роль | `my_own_namespace.yandex_cloud_elk.my_own_role` | Single-task роль: вызывает `my_own_module` со значениями из переменных |
| Playbook | `playbooks/site.yml` | Пример использования роли на `localhost` (инвентарь `playbooks/inventory`) |

## Требования

- ansible-core >= 2.15;
- Python на управляемом хосте: 2.7 или 3.x (модуль совместим с обеими версиями).

## Установка

Из собранного архива:

```bash
ansible-galaxy collection install my_own_namespace-yandex_cloud_elk-1.0.0.tar.gz
```

Из git-репозитория по тегу, через `requirements.yml`:

```yaml
---
collections:
  - name: https://github.com/deravchukma/my_own_collection.git
    type: git
    version: 1.0.0
```

```bash
ansible-galaxy collection install -r requirements.yml
```

## Модуль `my_own_module`

Создаёт на управляемом хосте текстовый файл с заданным содержимым.

- Идемпотентен: если файл уже содержит `content`, возвращает `changed: false`.
- Пишет сначала во временный файл, затем атомарно переносит его на место (`atomic_move`).
- Поддерживает режимы `--check` и `--diff`.

| Параметр | Тип | Обязательный | По умолчанию | Описание |
|---|---|---|---|---|
| `path` | path | да | — | Путь к файлу. Родительский каталог должен существовать |
| `content` | str | нет | `''` | Содержимое файла |

Возвращаемые значения: `path` (путь к файлу), `message` (что сделал модуль: `File created`, `File content updated`, `File already has the required content`).

```yaml
- name: Create a file with a greeting
  my_own_namespace.yandex_cloud_elk.my_own_module:
    path: /tmp/hello.txt
    content: "Hello, Netology!\n"
```

Полная документация: `ansible-doc my_own_namespace.yandex_cloud_elk.my_own_module`.

## Роль `my_own_role`

| Переменная | По умолчанию | Описание |
|---|---|---|
| `my_own_role_path` | `/tmp/my_own_role.txt` | Путь к создаваемому файлу (параметр `path` модуля) |
| `my_own_role_content` | `"Hello from my_own_role!\n"` | Содержимое файла (параметр `content` модуля) |

```yaml
- name: Create file with my_own_role
  hosts: localhost
  gather_facts: false
  roles:
    - role: my_own_namespace.yandex_cloud_elk.my_own_role
      vars:
        my_own_role_path: /tmp/custom.txt
        my_own_role_content: "Custom content\n"
```

## Запуск примера

```bash
ansible-playbook -i playbooks/inventory playbooks/site.yml
```

## Лицензия

GPL-3.0-or-later

## Автор

Mikhail Deravchuk ([@deravchukma](https://github.com/deravchukma))
