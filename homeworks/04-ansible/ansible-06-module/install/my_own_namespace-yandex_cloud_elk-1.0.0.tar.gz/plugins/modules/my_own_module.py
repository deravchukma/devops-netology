#!/usr/bin/python

# Copyright: (c) 2026, Mikhail Deravchuk (@deravchukma)
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

DOCUMENTATION = r'''
---
module: my_own_module

short_description: Creates a text file with the given content

version_added: "1.0.0"

description:
    - Creates a text file on the managed host at O(path) with the content from O(content).
    - If the file already exists with the same content, nothing is changed (idempotent).
    - The file is written to a temporary file first and then moved into place atomically.

options:
    path:
        description: Absolute path to the file on the managed host. The parent directory must exist.
        required: true
        type: path
    content:
        description: Text that the file must contain.
        required: false
        type: str
        default: ''

attributes:
    check_mode:
        support: full
    diff_mode:
        support: full

author:
    - Mikhail Deravchuk (@deravchukma)
'''

EXAMPLES = r'''
- name: Create a file with a greeting
  my_own_namespace.yandex_cloud_elk.my_own_module:
    path: /tmp/hello.txt
    content: "Hello, Netology!\n"

- name: Create an empty file
  my_own_namespace.yandex_cloud_elk.my_own_module:
    path: /tmp/empty.txt
'''

RETURN = r'''
path:
    description: Path to the file.
    type: str
    returned: always
    sample: '/tmp/hello.txt'
message:
    description: What the module did.
    type: str
    returned: always
    sample: 'File created'
'''

import os
import tempfile

from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.common.text.converters import to_bytes, to_native, to_text


def read_file(b_path):
    """Return the current file content as bytes, or None if the file does not exist."""
    if not os.path.exists(b_path):
        return None
    with open(b_path, 'rb') as f:
        return f.read()


def write_file(module, b_path, b_content):
    """Write content to a temporary file and move it into place atomically."""
    fd, tmp_path = tempfile.mkstemp(dir=module.tmpdir)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(b_content)
    except (IOError, OSError) as e:
        module.fail_json(msg='Unable to write temporary file: %s' % to_native(e))
    module.atomic_move(tmp_path, to_native(b_path))


def run_module():
    module_args = dict(
        path=dict(type='path', required=True),
        content=dict(type='str', required=False, default=''),
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    path = module.params['path']
    b_path = to_bytes(path, errors='surrogate_or_strict')
    b_content = to_bytes(module.params['content'], errors='surrogate_or_strict')

    result = dict(
        changed=False,
        path=path,
        message=''
    )

    if os.path.isdir(b_path):
        module.fail_json(msg='Path %s is a directory' % path, **result)

    b_dir = os.path.dirname(b_path) or b'.'
    if not os.path.isdir(b_dir):
        module.fail_json(msg='Parent directory %s does not exist' % to_native(b_dir), **result)

    b_current = read_file(b_path)

    if b_current == b_content:
        result['message'] = 'File already has the required content'
        module.exit_json(**result)

    result['changed'] = True
    result['message'] = 'File created' if b_current is None else 'File content updated'

    if module._diff:
        result['diff'] = dict(
            before_header=path,
            after_header=path,
            before=to_text(b_current) if b_current is not None else '',
            after=to_text(b_content),
        )

    if not module.check_mode:
        write_file(module, b_path, b_content)

    module.exit_json(**result)


def main():
    run_module()


if __name__ == '__main__':
    main()
