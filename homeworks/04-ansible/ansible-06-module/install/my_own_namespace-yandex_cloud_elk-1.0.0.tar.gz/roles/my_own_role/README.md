# Role `my_own_namespace.yandex_cloud_elk.my_own_role`

Single-task роль: создаёт текстовый файл модулем `my_own_namespace.yandex_cloud_elk.my_own_module`.

## Требования

Коллекция `my_own_namespace.yandex_cloud_elk` установлена (модуль входит в неё же).

## Переменные

| Переменная | По умолчанию | Описание |
|---|---|---|
| `my_own_role_path` | `/tmp/my_own_role.txt` | Путь к файлу, родительский каталог должен существовать |
| `my_own_role_content` | `"Hello from my_own_role!\n"` | Содержимое файла |

## Зависимости

Нет.

## Пример playbook

```yaml
- name: Create file with my_own_role
  hosts: localhost
  gather_facts: false
  roles:
    - role: my_own_namespace.yandex_cloud_elk.my_own_role
```

## Лицензия

GPL-3.0-or-later

## Автор

Mikhail Deravchuk (@deravchukma)
